/*
 *  Copyright(C) 2021 by Yukiya Ishioka
 */

#include <stdio.h>
#include <stdarg.h>
#include "pico.h"
#include "pico/stdlib.h"

#include "hardware/regs/m0plus.h"
#include "hardware/regs/resets.h"
#include "hardware/structs/padsbank0.h"
#include "hardware/structs/uart.h"

#include "hardware/clocks.h"
#include "hardware/resets.h"
#include "hardware/gpio.h"
#include "hardware/uart.h"
#include "hardware/irq.h"

#include "target_syssvc.h"

#ifndef PICO_NO_RAM_VECTOR_TABLE
#define PICO_NO_RAM_VECTOR_TABLE 0
#endif

#define UART_TX_PIN 20
#define UART_RX_PIN 21


void  pico_gpio_btn_init( void )
{
    gpio_init(14);
    gpio_set_dir(14, GPIO_IN);
}

int  pico_gpio_btn1( void )
{
  return  (int) !gpio_get(14);
}

int  pico_gpio_btn2( void )
{
  return  (int) 0;
}


void  pico_gpio_led_init( void )
{
    gpio_init(25);
    gpio_set_dir(25, GPIO_OUT);
    gpio_put(25,0);
}


void  pico_gpio_led_set( int on )
{
    gpio_put(25,on);
}

void  pico_clock_init( void )
{
    // After calling preinit we have enough runtime to do the exciting maths
    // in clocks_init
    clocks_init();
}

inline  static  uart_inst_t *pico_uart_port( int id )
{
  if( id != 0 ) {
    return  uart1;
  }

  return  uart0;
}


int  pico_uart_putready( int id )
{
    uart_inst_t *uart = pico_uart_port(id);
    unsigned int  imsc = uart_get_hw(uart)->imsc;
    unsigned int  ris = uart_get_hw(uart)->ris;

    if( (imsc & UART_UARTIMSC_TXIM_BITS) != 0 && (ris & UART_UARTRIS_TXRIS_BITS) != 0 ) {
        return 1;
    }
    return  0;
}


int  pico_uart_getready( int id )
{
    uart_inst_t *uart = pico_uart_port(id);
    unsigned int  imsc = uart_get_hw(uart)->imsc;
    unsigned int  ris = uart_get_hw(uart)->ris;

    if( (ris & (UART_UARTRIS_OERIS_BITS | UART_UARTRIS_BERIS_BITS 
                | UART_UARTRIS_PERIS_BITS | UART_UARTRIS_FERIS_BITS)) != 0 ) {
        /* clear error interrupt */
        hw_write_masked(&uart_get_hw(uart)->icr ,0,
                    (UART_UARTICR_OEIC_BITS|UART_UARTICR_BEIC_BITS|UART_UARTICR_PEIC_BITS|UART_UARTICR_FEIC_BITS));
        (void)uart_get_hw(uart)->dr;
        return 0;
    }

    if( (imsc & UART_UARTIMSC_RXIM_BITS) != 0 && (ris & UART_UARTRIS_RXRIS_BITS) != 0 ) {
        return 1;
    }
    return  0;
}


void  pico_uart_putc_raw( int id, char c )
{
    uart_putc_raw( pico_uart_port(id), c );
}


char  pico_uart_getc( int id )
{
    return  uart_getc( pico_uart_port(id) );
}


/*
 *  flag : 1 = enable irq
 *         0 = disable irq
 */
void  pico_uart_irq_ctrl_tx( int id, int flag )
{
    uart_inst_t *uart = pico_uart_port(id);

    hw_write_masked(&uart_get_hw(uart)->imsc ,bool_to_bit((bool)flag) << UART_UARTIMSC_TXIM_LSB,
                    UART_UARTIMSC_TXIM_BITS);
}


void  pico_uart_irq_ctrl_rx( int id, int flag )
{
    uart_inst_t *uart = pico_uart_port(id);

    hw_write_masked(&uart_get_hw(uart)->imsc ,bool_to_bit((bool)flag) << UART_UARTIMSC_RXIM_LSB,
                    UART_UARTIMSC_RXIM_BITS);
}


void  pico_uart_init( int id, int bps )
{
    uart_inst_t *uart = pico_uart_port(id);

    uart_init(uart, bps);
    uart_set_fifo_enabled( uart, false );

    // Set the TX and RX pins by using the function select on the GPIO
    // Set datasheet for more information on function select
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);

#if 0  // for TEST
    //uart_puts(uart, "Initialize UART!\n");
    //uart_putc_raw( uart, 'A' );
    //uart_putc_raw( uart, '\n' );

  {
    char  c;
    uart_inst_t *uart = pico_uart_port(id);
    while( 100 ) {
      c = uart_getc( uart );
      uart_putc( uart, c );
    }
  }
#endif
}

#if 0
unsigned int  debug_uart_imsc;
unsigned int  debug_uart_ifls;
#endif

void  pico_uart_irq_init( int id, int bps )
{
    uart_inst_t *uart = pico_uart_port(id);

    uart_init( uart, bps );
    uart_set_fifo_enabled( uart, false );
    uart_set_irq_enables( uart, true, true );

    // Set the TX and RX pins by using the function select on the GPIO
    // Set datasheet for more information on function select
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
}


void  pico_uart_deinit( int id )
{
    uart_deinit(pico_uart_port(id));
}


void  pico_hard_init( void )
{
    // Reset all peripherals to put system into a known state,
    // - except for QSPI pads and the XIP IO bank, as this is fatal if running from flash
    // - and the PLLs, as this is fatal if clock muxing has not been reset on this boot
    reset_block(~(
            RESETS_RESET_IO_QSPI_BITS |
            RESETS_RESET_PADS_QSPI_BITS |
            RESETS_RESET_PLL_USB_BITS |
            RESETS_RESET_PLL_SYS_BITS
    ));

    // Remove reset from peripherals which are clocked only by clk_sys and
    // clk_ref. Other peripherals stay in reset until we've configured clocks.
    unreset_block_wait(RESETS_RESET_BITS & ~(
            RESETS_RESET_ADC_BITS |
            RESETS_RESET_RTC_BITS |
            RESETS_RESET_SPI0_BITS |
            RESETS_RESET_SPI1_BITS |
            RESETS_RESET_UART0_BITS |
            RESETS_RESET_UART1_BITS |
            RESETS_RESET_USBCTRL_BITS
    ));

    pico_clock_init();
    pico_gpio_led_init();

    pico_uart_init( 1, BPS_SETTING );
}


void  panic(const char *fmt, ...)
{
    while( 1 );
}

void irq_set_exclusive_handler(uint num, irq_handler_t handler)
{
}

void irq_set_enabled(uint num, bool enabled)
{
}

void irq_add_shared_handler( uint num, irq_handler_t handler, uint8_t order_priority )
{
}

void irq_remove_handler( uint num, irq_handler_t handler )
{
}

