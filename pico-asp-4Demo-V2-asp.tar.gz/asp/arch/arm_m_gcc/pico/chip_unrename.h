/* This file is generated from target_rename.def by genrename. */

/* This file is included only when target_rename.h has been included. */
#ifdef TOPPERS_CHIP_RENAME_H
#undef TOPPERS_CHIP_RENAME_H


/*
 * chip_config.c
 */
#undef target_initialize
#undef target_exit

#ifdef TOPPERS_LABEL_ASM


/*
 * chip_config.c
 */
#undef _target_initialize
#undef _target_exit

#endif /* TOPPERS_LABEL_ASM */

#include "arm_m_gcc/common/core_unrename.h"

#endif /* TOPPERS_CHIP_RENAME_H */
